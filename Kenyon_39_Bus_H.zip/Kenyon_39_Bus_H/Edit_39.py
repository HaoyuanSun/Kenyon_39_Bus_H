# Rick Wallace Kenyon
# First constructed in December 2019
# Open Maui Workspace with five namespaces, for editing purposes

#!python3
import mhrc.automation, os, logging, time, sys
sys.path.append(r'C:\Users\rkenyon\Desktop\Maui\PSCAD\Maui_32')
import Wallace_PSCAD_Python as WPP
from sys import argv
path = os.getcwd()

simulate = argv[1] # If True, runs simulation
scenario = argv[2] # Simulation indicator
scenario_run = True

# Intel isn't installed on CU server
IF32 = 'Intel 19.1.254'
GF = '4.2.1'
intel = False
IF32_suffix = '.if15_x86'
GF_suffix = '.gf42'
# Snapstart suffix
if intel:
    snap_ext = IF32_suffix
else:
    snap_ext = GF_suffix

Freq_meters = True
Pm_meters = True

# Made gen at 30 800 MVA to compensate for the 1200 MVA at bus 39
power_flow_elem = ['Base_MVA','P_Setpoint','Q_Setpoint','V_Setpoint','Ph_Setpoint']
gen_types = ['Ideal','GFM','SG']
power_flow = [
    {'Bus' : 30, 'Proj' : 'NW_39', 'Base_MVA' : 800, 'Base_V' : 18.0, 'P_Setpoint' : 250, 'Q_Setpoint' : 83.2, 'V_Setpoint' : 1.0475, 'Ph_Setpoint' : -3.73, 'Gen_Type' : 'GFM'}, # ratings/PQ in MVA, voltage in per unit, Ph in degrees
    {'Bus' : 31, 'Proj' : 'SW_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 571.3, 'Q_Setpoint' : 363.9, 'V_Setpoint' : 0.982, 'Ph_Setpoint' : -1.59, 'Gen_Type' : 'GFM'},
    {'Bus' : 32, 'Proj' : 'SE_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 650.0, 'Q_Setpoint' : 1.5, 'V_Setpoint' : 0.9831, 'Ph_Setpoint' : 1.79, 'Gen_Type' : 'GFM'},
    {'Bus' : 33, 'Proj' : 'SE_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 632.0, 'Q_Setpoint' : 69.7, 'V_Setpoint' : 0.9972, 'Ph_Setpoint' : 2.87, 'Gen_Type' : 'GFM'},
    {'Bus' : 34, 'Proj' : 'SE_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 508.0, 'Q_Setpoint' : 148.8, 'V_Setpoint' : 1.0123, 'Ph_Setpoint' : 1.46, 'Gen_Type' : 'GFM'},
    {'Bus' : 35, 'Proj' : 'East_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 650.0, 'Q_Setpoint' : 167.0, 'V_Setpoint' : 1.0493, 'Ph_Setpoint' : 4.78, 'Gen_Type' : 'GFM'},
    {'Bus' : 36, 'Proj' : 'East_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 560.0, 'Q_Setpoint' : 75.4, 'V_Setpoint' : 1.0635, 'Ph_Setpoint' : 7.46, 'Gen_Type' : 'GFM'},
    {'Bus' : 37, 'Proj' : 'NW_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 540.0, 'Q_Setpoint' : -35.3, 'V_Setpoint' : 1.0278, 'Ph_Setpoint' : 2.05, 'Gen_Type' : 'GFM'},
    {'Bus' : 38, 'Proj' : 'NE_39', 'Base_MVA' : 1000, 'Base_V' : 18.0, 'P_Setpoint' : 830.0, 'Q_Setpoint' : -0.5, 'V_Setpoint' : 1.0265, 'Ph_Setpoint' : 7.3, 'Gen_Type' : 'GFM'},
    {'Bus' : 39, 'Proj' : 'SW_39', 'Base_MVA' : 1200, 'Base_V' : 18.0, 'P_Setpoint' : 1000.0, 'Q_Setpoint' : -36.50, 'V_Setpoint' : 1.03, 'Ph_Setpoint' : -10.06, 'Gen_Type' : 'GFM'},
]

gen_settings = [
    {'Name' : 'Gen_30_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_31_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_32_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_33_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_34_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_35_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_36_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_37_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_38_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5},
    {'Name' : 'Gen_39_SG', 'Droop_gain' : 0.05, 'H' : 4, 'T_turbine' : 0.5}
]

# Adjust gen-type for scenario
if scenario_run:
    for elem in power_flow:
        if ( int(elem['Bus']) - 30 ) < int(scenario):
            elem['Gen_Type'] = 'GFM' 
        else:
            elem['Gen_Type'] = 'SG'


# Note, all suffixs will added after namespace name, and be placed/exist in a sub directory with (namespace).gf42,
channel_suffix = '.out'    # Channel suffix, added after the namespace
snapshot_suffix = '_Test.snp'    # Snap suffix, added after the namespace
snapstart_suffix = '_200714.snp'   # Suffix for snapshot start file
sim_set_name = '39_Bus'

# Error flag, simulation won't execute if this is not zero
ERROR = 0

# Simulation settings
settings = {
    'time_duration' : 20,  # Length of simulation in seconds
    'time_step' : 25,   # Time Step, in microseconds
    'StartType': 0, # 0: Standard Startup with no snapshot, 1 is for start from snapshot
    'PlotType' : 1, # 0 for no channel output, 1 for channel output based on 'channel_suffix'
    'SnapType' : 0, # 0 is to take no snapshot, 1 is to take a single snapshot
    'SnapTime' : 1.0, # Time of snapshot, in seconds
    'Disabled_Channels' : 0 # Disable channels; note, cannot take a snapshot after this and then turn them on!
}

# Release timing
sim_timing_change = True # Change various timings in the simulation
sim_timing = [
    {'Name' : 'Time_S2M','Value' : 1}, # Release the machines
    {'Name' : 'Time_Rotor','Value' : 1.5}, # Release the exciters
    {'Name' : 'Time_Governor','Value' : 1.5}, # Release the governors
    {'Name' : 'Time_GFM', 'Value' : 2.5}, # Release GFM
    {'Name' : 'T_LoadStep_15', 'Value' : 5.0}
]

# Log 'INFO' messages & above.  Include level & module name. Remove log file first
logging.basicConfig(level=logging.INFO,
                    format="%(levelname)-8s %(name)-26s %(message)s",filename='app.log')
# Ignore INFO msgs from automation (eg, mhrc.automation.controller, ...)
logging.getLogger('mhrc.automation').setLevel(logging.WARNING)
LOG = logging.getLogger('main') # Set Handle (correct name?)
controller = mhrc.automation.controller() # Used to access version information

# Verify 4.2.1 Fortran version, as this is compatible with the Etran library
fortrans = controller.get_paramlist_names('fortran')
LOG.info("FORTRAN Versions: %s", fortrans)
for fortran in fortrans:
    if intel:
        if fortran == IF32:
            fortran_ver = fortran
    else:
        if GF in fortran:
            fortran_ver = fortran

LOG.info("Using FORTRAN Version: %s", fortran_ver)

# Launch PSCAD
# What version am I using? Fortran version? Keep the window open: minimize=False
pscad = mhrc.automation.launch_pscad(fortran_version=fortran_ver)
pscad.settings(solder_wires='false') # Supposedly speeds up the simulation to have these not visible

# Load the workspace
pscad.load(os.path.join(path, "IEEE_39_Bus.pswx"))
workspace = pscad.workspace() # Establish workspace handle
projects = workspace.projects()
cases = [prj for prj in projects if prj['type'] == 'Case']

# Steps through and loads all of the settings for the namespaces, note, it
for case in cases:
    project = workspace.project(case['name']) # Establish namespace handle
    project.focus()
    LOG.info('Namespace %s is loaded.' % case['name'])
    params = project.parameters()
    project.set_parameters(time_duration=settings['time_duration'])
    project.set_parameters(time_step=settings['time_step'])

    # Add path to the snapshot startup file, assuming exists in fortran directory in main path directory, Attaches snapstart_suffix
    project.set_parameters(StartType=settings['StartType'])
    if settings['StartType'] == 1:
        snap_path = os.path.join(path,case['name'] + snap_ext,case['name'] + snapstart_suffix)
        if os.path.exists(snap_path):
            project.set_parameters(startup_filename=snap_path)
        else:
            LOG.info('Snapshot file for %s DNE.' % case['name'])
            ERROR += 1
    
    # Create channel output file name, stored in (namespace).gf42 directory, with channel_suffix added
    project.set_parameters(PlotType=settings['PlotType'])
    if settings['PlotType'] == 1:
        channel_path = case['name'] + channel_suffix
        project.set_parameters(output_filename=channel_path)

    # Create snap save file name, stored in (namespace).gf42 directory, with snap_suffix added
    project.set_parameters(SnapType=settings['SnapType'])
    if settings['SnapType'] == 1:
        snapsave_file = case['name'] + snapshot_suffix
        project.set_parameters(snapshot_filename=snapsave_file)
        project.set_parameters(SnapTime=settings['SnapTime'])

cases = WPP.Get_Cases(workspace,0)
canvases = WPP.Get_Case_Canvases(workspace)

sim_numbers = WPP.flatten(WPP.Find_All_Components(canvases,'const'))

# Changes according to event selection
# If None is argv[2], no updates. If no event match, raises error
# Should now turn all timers off

# Power Flow Control
changed = 0
for setting in sim_numbers:
    parms = setting.get_parameters()
    for gen in power_flow:
        if str(gen['Bus']) in parms['Name']:
            for elem in power_flow_elem:
                if elem in parms['Name']:
                    setting.set_parameters(Value=gen[elem])
                    changed +=1
                if 'Ph_Setpoint_Rad' in parms['Name']:
                    Ph_Rad = (gen['Ph_Setpoint']/360) * (2 * 3.1415)
                    setting.set_parameters(Value=Ph_Rad)
                    changed +=1
                
print('Updated %r power flow parameters.' % changed)

# Gen Layer Control
for gen in power_flow:
    proj = workspace.project(gen['Proj'])
    proj.focus()
    for elem in gen_types:
        if gen['Gen_Type'] == elem:
            layer_enable = elem + '_' + str(gen['Bus'])
            proj.set_layer(layer_enable,'enabled')
        else:
            layer_disable = elem + '_' + str(gen['Bus'])
            proj.set_layer(layer_disable,'disabled')

# Update Gen settings
gens = WPP.flatten(WPP.Find_All_Components(canvases,'Generic_SG_1'))
for gen in gens:
    parms = gen.get_parameters()
    for elem in power_flow:
        if str(elem['Bus']) in parms['Name']:
            base_v = round(elem['Base_V'] / 3**(1/2), 4)
            base_s = elem['Base_MVA']
            base_i = round((base_s / 3) / base_v, 4)

    for gen_set in gen_settings:
        if gen_set['Name'] == parms['Name']:
            gen.set_parameters(Vbase=base_v, Ibase=base_i, Droop_gain=gen_set['Droop_gain'], H=gen_set['H'], T_turbine=gen_set['T_turbine'])
            
# Frequency/Pm Meter Layer control
for case in cases:   
    case.focus()
    if Freq_meters:
        case.set_layer('Freq_meters','enabled')
    else: 
        case.set_layer('Freq_meters','disabled')
    if Pm_meters:
        case.set_layer('Pm_meters','enabled')
    else: 
        case.set_layer('Pm_meters','disabled')

# Update release timings
if not settings['StartType'] == 1:
    if sim_timing_change:
        count = 0
        for setting in sim_timing:
            for sig in sim_numbers:
                parms = sig.get_parameters()
                if parms['Name'] == setting['Name']:
                    sig.set_parameters(Value=setting['Value'])
                    count += 1
        print('Updated %r namespace simulation time elements.' % count)

# Checks for the specified simulation set in the workspace
sim_sets = workspace.list_simulation_sets()
if sim_set_name in sim_sets:
    sim_set = workspace.simulation_set(sim_set_name)
else:
    LOG.info('Simulation Set %s not in workspace.' % sim_set_name)
    ERROR += 1

# Runs the simulation
if ERROR == 0:
    print('Successful start up. Running simulation....')
    if simulate == 'True':
        sim_set.run()
else:
    LOG.info('Cannot run the simulation because of %r errors.' % ERROR)
    print('Cannot run the simulation because of %r errors.' % ERROR)

# Exit PSCAD
# if simulate == 'True':
#     pscad.quit()