import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

num_of_gen = 10
folder_name = 'load_increase_at_39'

pgen = pd.read_csv(f'./{folder_name}/Data__Temp_Pgen.csv')
time = pgen['# Time']

index_1s = time[time >= 1].index[0]
time_truncate = time[index_1s:]

for i in range(num_of_gen):
    pgen_i = pgen.iloc[:, i+1]
    pgen_i_truncate = pgen_i[index_1s:]
    pgen_i_norm = (pgen_i_truncate - min(pgen_i_truncate)) / (max(pgen_i_truncate) - min(pgen_i_truncate))
    name_i = pgen.columns[i+1]
    plt.plot(time_truncate, pgen_i_norm, label=name_i)

plt.axvline(x=2, linestyle='--')
plt.xlim([1.986, 2.0222])
plt.ylim([-0.04, 1])
plt.legend(loc='upper left')
plt.show()


