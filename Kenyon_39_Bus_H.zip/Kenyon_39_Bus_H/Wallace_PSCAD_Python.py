# Rick Wallace Kenyon
# Initially created, January 2020
# A module of pscad/python interfacing functions

import math
import numpy as np
import os
import csv

def Get_Librarys(workspace_hand):
    # Returns a list of the workspace libraries
    projects = workspace_hand.projects()
    libs = [prj for prj in projects if prj['type'] == 'Library']
    return libs

def Get_Cases(workspace_hand,output=False):
    # Return list of case handles
    # Provides name list as well if output = 1
    projects = workspace_hand.projects()
    cases = [prj for prj in projects if prj['type'] == 'Case']
    case_handles = []
    for case in cases:
        case_handles.append(workspace_hand.project(case['name']))
    if output == 1:
        return case_handles, cases
    else:
        return case_handles

def Save_Cases(cases):
    for case in cases:
        case.save()

def Get_Modules(canvas_handle):
    # Finds all modules in canvas_handle, skips over Tlins and Cables
    # Returns list of module handles
    components = canvas_handle.find_all()
    modules = []
    if components != []:
        for comp in components:
            try:
                if comp.is_module() == True:
                    modules.append(comp)
            except Exception:
                pass
    else:
        print('No modules on this canvas.')
    return modules

def Is_Component(canvas_handle,comp_name):
    # Checks the canvas_handle for a component by comp_name
    # Returns list of all component handles with that name
    desired_components = []
    components = canvas_handle.find_all()
    for comp in components:
        try:
            comp_def = comp.get_definition()
            if comp_def.name == comp_name:
                desired_components.append(comp)
        except Exception:
            pass
    return desired_components

def Get_Case_Canvases(workspace_handle):
    # Walks through all cases in workspace, and finds modules with canvases (and library defs too)
    # Only finds canvases established in namespaces, not those in librarys
    # Note, this will only step into modules from the main page (i.e. single step)
    # Note, don't use scoped name! It's possible to establish a handle for a non-existent canvas
    cases = Get_Cases(workspace_handle,0)
    canvases = []
    for case in cases:
        temp_can = case.user_canvas('main')
        canvases.append(temp_can)
        modules = Get_Modules(temp_can)
        if modules != []:
            for mod in modules:
                mod_def = mod.get_definition()
                if case.name in mod_def.scope:
                    canvases.append(case.user_canvas(mod_def.name))
    return canvases

def Generator_Canvases(canvas_handles,gen_keyword):
    # Takes the previously created set of canvas handles and collects only generator modules
    gens = []
    for canvas in canvas_handles:
        if gen_keyword in canvas.name:
            gens.append(canvas)
    return gens

def Update_Gen_Init(gen_handle,workspace,settings):
    # Takes a generator canvas handle (assumed to be an Etran initialization block) and a dict of settings
    # Settings are assumed to be 'Volts', 'Phase', 'P', 'Q'
    proj_name = gen_handle._scope['project']
    proj = workspace.project(proj_name)
    proj.focus()
    # Layer Management
    if settings['Online']:
        proj.set_layer(settings['Name'],'enabled')
        print('Generator %s online, enabled layer.' % settings['Name'])
    if not settings['Online']:
        proj.set_layer(settings['Name'],'disabled')
        print('Generator %s offline, disabled layer.' % settings['Name'])
        return 0, 0, 0

    # Update Init Block Parameters
    init_block = Find_All_Components(gen_handle,'Electranix_Init_Conditions')
    if len(init_block) != 1:
        print('Multiple/no Init Blocks in %s, cannot continue.' % gen_handle.name)
        return 1
    init_block[0].set_parameters(Volts=settings['Volts'],Phase=settings['Phase'],P=settings['P'],Q=settings['Q'])
    
    # Verify Settings
    parms = init_block[0].get_parameters()
    print('Generator %s updated to V: %0.3f, Ph: %0.3f, P: %0.3f, Q: %0.3f.' % (settings['Name'],float(parms['Volts']),float(parms['Phase']),float(parms['P']),float(parms['Q'])))
    return 0, float(parms['P']), float(parms['Q'])
    
def Gen_Dispatch(gen_handles,workspace,settings):
    gen_set_count = len(settings)
    gen_model_count = len(gen_handles)
    total_P = 0
    total_Q = 0

    # Verify consistent number of settings provided with gens in model
    if gen_set_count != gen_model_count:
        print('Inconsistent number of generator settings vs. in model. Cannot proceed.')
        return 1
    
    # March through and change generator settings
    success = 0
    for gen_set in settings:
        for gen_handle in gen_handles:
            if gen_set['Name'] == gen_handle._scope['definition']:
                result = Update_Gen_Init(gen_handle,workspace,gen_set)
                success += result[0]
                total_P += result[1]
                total_Q += result[2]
    
    if success == 0:
        print('Successfully adjusted dispatch at %r generators. Total P: %r MW, Total Q: %r Mvar' % (gen_set_count,round(total_P,3),round(total_Q,3)))
        return 0
    elif success != 0:
        print('Incomplete settings adjustment, will not continue.')
        return 1
                
def Find_All_Components(canvas_handles,comp_name,count=False):
    # Takes list of canvas_handles, or single object handle
    # Checks each for the component with comp_name
    # Returns nested list if input is list each canvas captured by a sub level, otherwise, a single list
    components = []
    if isinstance(canvas_handles,list):
        for canvas in canvas_handles:
            try:
                components.append(Is_Component(canvas,comp_name))
            except Exception:
                pass
    else:
        try:
            components = Is_Component(canvas_handles,comp_name)
        except Exception:
            pass
    return components

def Total(comp_sets,parm_name):
    # Sums the string to float values of the selected parm_name
    total = 0
    quantity = 0
    if any(isinstance(i,list) for i in comp_sets):
        comp_sets = flatten(comp_sets)
    for comp in comp_sets:
        parm = comp.get_parameters()
        total += float(parm[parm_name])
        quantity += 1
    return total, quantity

def Get_Total(canvas_handles,comp_name,parm_name):
    # Single Call total, finds components and sums values
    comp_sets = Find_All_Components(canvas_handles,comp_name)
    return Total(comp_sets,parm_name)


def Current_Settings(canvas_handles,comp_name,parm_name,save_file=True):
    # Collects handles for all comp_names in canvas_handles
    # Generally hard coded for P/Q settings 
    # collects bus number (assuming largest number in name), and relavant parm value, in np array
    # defaults to save, returns array if save_file = False
    temp_sets = flatten(Find_All_Components(canvas_handles,comp_name))
    comp_sets = list(filter(None,temp_sets))
    quant = len(comp_sets)
    data = np.empty([quant,2])
    i = 0
    for comp in comp_sets:
        parm = comp.get_parameters()
        name = parm['Name'].split('_')
        nums = [num for num in name if num.isdigit()]
        bus = max(nums)
        data[i,0] = int(bus)
        data[i,1] = float(parm[parm_name])
        i += 1
    
    if save_file:
        save_header = comp_name + ', ' + parm_name
        save_name = comp_name + '_' + parm_name + '.csv'
        np.savetxt(save_name, data, delimiter=",",header = save_header)
    else:
        return data

def Add_Paired_Signal(canvas_handle,comp,comp_parm,x_pos,y_pos,output_channel=True):
    # Add signal paired to comp_parm of comp handle
    # Grid is 17.5 x 17.5 points
    parms = comp.get_parameters()
    if parms['Name'] != '':
        signal_name = parms[comp_parm] 
        new_signal = canvas_handle.add_component('master','datalabel',x_pos,y_pos)
        new_signal.set_parameters(Name=signal_name)
        if output_channel:
            pgb = canvas_handle.add_component('master','pgb',x_pos,y_pos)
            pgb.set_parameters(UseSignalName=1)
        return new_signal, pgb
    

def Add_Signals(canvas_handle,comp_name,comp_parm,per_row,init_x,init_y,x_spacing,y_spacing,layer,add_layer=False):
    # Add signals (and channels) iteratively for all comp_names on canvas paired with comp_parm
    # puts all channels on a layer if add_layer=True # layer must exist!
    # Grid is 17.5 x 17.5 points: x_spacing/y_spacing is number of point spacing between installs
    
    comps = Find_All_Components(canvas_handle,comp_name)
    count = len(comps)
    for i in range(0,count):
        x_pos = init_x + ( ( i % per_row ) * (17.5 * x_spacing) )       
        y_pos = init_y + ( (17.5 * y_spacing) * math.floor(i/per_row) )   
        signal, channel = Add_Paired_Signal(canvas_handle,comps[i],comp_parm,x_pos,y_pos)
        if add_layer:
            signal.add_to_layer(layer)
            channel.add_to_layer(layer)

# OpenUnpack(file,load=False,DG=False,P3=False,Tap=False,BusChannel=False,VoltageLevel=False,PSSE_Data=False,Skip=True):
def Change_DG(canvases,DG_type,file):
    # Updates the real and reactive of DG
    # Find DG components
    if not DG_type == 'P1' and not DG_type == 'P2' and not DG_type == 'P3':
        print('Not the right DG type.')
        return 1
    DG_name = 'DG_Current_Source_' + DG_type
    if not os.path.exists(file):
        print('File DNE.')
        return 1
    comps = flatten(Find_All_Components(canvases,DG_name))

    # Unpack data
    if DG_type == 'P3':
        DG_data = OpenUnpack(file,load=False,DG=True,P3=True)
    else:
        DG_data = OpenUnpack(file,False,True,False,False)

    print('Updating DG type %s...' % DG_type)
    # Work through and update
    missed = 0
    for comp in comps:
        found = False
        parms = comp.get_parameters()
        bus_num = parms['Name'].split('_')[1]
        for unit in DG_data:
            if unit['Bus'] == bus_num:
                found = True
                if DG_type == 'P3':
                    comp.set_parameters(Sn=unit['Mbase'],P0=unit['P'],pf=unit['PF'])
                else:
                    comp.set_parameters(Sn=unit['Mbase'],P0=unit['P'])
                #print('Found/updated data for DG unit at bus %r.' % bus_num)
                break
        if found == False:
            print('Did not find data for DG unit at bus %r; skipped.' % bus_num)
            missed += 1
    
    # Print totals
    print('Missed %i DG units.' % missed)
    P_total = Total(comps,'P0')
    print('New DG type %s real power total %r' % (DG_type,round(P_total[0],3)))


def Change_Load(canvases,scale_existing=True,scale_val=1.0,load_file=''):
    # Takes a .csv and changes all loads in the file. Reports back on initial and final values
    # scale_existing> True will simply scale the existing load values by the scale_val
    # scale_existing> False will take provided load values, and change the loads and scale according to scale_val
    # Maintains 
    load_handles = Find_All_Components(canvases,'Load_Wrapper') # For PSCAD
    # load_handles = Find_All_Components(canvases,'Electranix_Load') # For Etran loads
    if any(isinstance(i,list) for i in load_handles):
        load_handles = flatten(load_handles)

    # Finds initial values of the system
    Real = Total(load_handles,'PO')
    Reactive = Total(load_handles,'QO')
    PF = Real[0] / (Real[0]**2 + Reactive[0]**2)**(1/2)
    print('Initial totals are %0.3f MW, and %0.3f Mvar' % (Real[0]*3,Reactive[0]*3))
    print('Initial system power factor is %0.3f' % PF)

    # Use file
    if scale_existing == False:
        UpdatePSCADFixed(load_file,canvases)
        return 0

    # Just scale
    if scale_existing == True:
        new_real = 0
        new_reactive = 0
        # Move through and change all loads proportionally. Maintains power factor for reactive set points
        for load in load_handles:
            parm = load.get_parameters()
            Pcur = float(parm['PO'])
            Qcur = float(parm['QO'])
            # I think I don't have to do this with the power factor, can just equally scale
            #pf = Pcur / (Pcur**2 + Qcur**2)**(1/2)
            Ptemp = Pcur * scale_val
            new_real += Ptemp
            #parity = 1
            #if Qcur < 0:
            #    parity = -1
            #Qtemp = round(parity * Ptemp * ((1/(pf**2)) - 1)**(1/2),4)
            Qtemp = Qcur * scale_val
            new_reactive += Qtemp
            load.set_parameters(PO=str(Ptemp),QO=str(Qtemp))
        # Verify Change
        New_Real = Total(load_handles,'PO')
        New_Reactive = Total(load_handles,'QO')
        New_PF = New_Real[0] / (New_Real[0]**2 + New_Reactive[0]**2)**(1/2)
        if round(New_Real[0],1) == round(new_real,1):
            print('All loads scaled from existing values. New totals are %0.3f MW, and %0.3f Mvar. \n Scaling factor implemented is %0.3f.' 
            % (New_Real[0],New_Reactive[0],float(New_Real[0]/Real[0]))) 
            print('New system power factor is %0.3f.' % New_PF)
            return 0
        else:
            print('Implementation was not correct, real power not set correctly.')
            return 1

def GatherOutputNames(canvases,prefix,save=False):
    signals = flatten(Find_All_Components(canvases,'datalabel'))
    data = []
    for signal in signals:
        parms = signal.get_parameters()
        if parms['Name'].split('_')[0] == prefix:
            data.append(parms['Name'])
    data = list(dict.fromkeys(data))
    if save:        
        filename = prefix + '_Channel_Names.csv'
        with open(filename, 'w',newline='\n') as file:
            write = csv.writer(file)
            for elem in data:
                write.writerow([elem])
        file.close()
        print('Succesfully wrote %s channel names to %s' % (prefix, filename))
    return data 

output_pre = [
    'Pgen',
    'Qgen',
    'Pdg',
    'Qdg',
    'Pload',
    'Qload',
    'V',
    'Ph',
    'FreqMaui',
    'Pufls',
    'Qufls',
    'TMgen',
    'TEgen',
    'Efgen',
    'Iabc',
    'Vabc',
    'BRK',
    'RTrip'
    ]

output_pre_39 = [
    'Pgen',
    'Qgen',
    'V',
    'Ph',
    'Freq',
    'Pm'
]

def ChannelMapFile(canvases,prefixes):
    for prefix in prefixes:
        GatherOutputNames(canvases,prefix,True)


def Save_Close(workspace,pscad_hand):
    cases = Get_Cases(workspace)
    Save_Cases(cases)
    pscad_hand.quit()
    quit()
    
####-----------------
#---Specific Functions
####-----------------

def Set_PQVPh_Names(components,meter_type):
    for comp in components:
        parms = comp.get_parameters()
        name = parms['Name'].split('_')
        if meter_type in name:
            comp.set_parameters(MeasP=1,MeasQ=1,MeasPh=2,RMS=1)
            comp.set_parameters(P='P'+meter_type.lower()+'_'+name[2])
            comp.set_parameters(Q='Q'+meter_type.lower()+'_'+name[2])
            comp.set_parameters(Vrms='V_'+name[2])
            comp.set_parameters(Ph='Ph_'+name[2])

def Change_Parameters(components,new_setting):
    # Changes parameters of components. Still haven't figured out how to pass keyword for set_parameters through function
    comp_handles = flatten(components)
    for comp in comp_handles:
        comp.set_parameters(Pscale_sel=new_setting)

def Delete_Signal_Name(components):
    # Changes parameters of components. Still haven't figured out how to pass keyword for set_parameters through function
    comp_handles = flatten(components)
    for comp in comp_handles:
        parms = comp.get_parameters()
        if parms['Name'] == 'TypTr2_0004_to_0009':
                comp.set_parameters(Name='')

def SC_Meter_SetUp(comp_sets):
    # Uses name of SC Meter, assumed to be SCR_Meter_x, and names output channels with x
    # Also, defaults the simulation time to 100, and device rating to 1
    for comps in comp_sets:
        for comp in comps:
            comp.add_to_layer('SC_meters')
            parms = comp.get_parameters()
            name_pieces = parms['Name'].split('_')
            current_label = 'SC_' + name_pieces[2]
            mva_label = 'SCmva_' + name_pieces[2]
            ratio_label = 'SCR_' + name_pieces[2]
            comp.set_parameters(SC_output=current_label,SCmva_output=mva_label,SCR_output=ratio_label,P_mw=1.0,T_test=101,Bypass_generation=1,Breaker_gen=0)
    
def Add_Load_PQ_Signal_Names(comp_sets):
    # Adds real and reactive power output labels for all of the comps
    # Hard coded to operate with Etran loads, and add name based on bus number
    # Amended hard code to add dg to P and Q of DG loads
    for comps in comp_sets:
        for comp in comps:
            parms = comp.get_parameters()
            name_pieces = parms['P_out'].split('_')
            real_label = 'Pdg_' + name_pieces[1] + '_' + name_pieces[2]
            reactive_label = 'Qdg_' + name_pieces[1] + '_' + name_pieces[2]
            current_label = 'Idg_' + name_pieces[1] + '_' + name_pieces[2]
            voltage_label = 'Vdg_' + name_pieces[1] + '_' + name_pieces[2]
            comp.set_parameters(P_out=real_label,Q_out=reactive_label,voltage_out=voltage_label,current_out=current_label)

#### DG Setup Code ####
# comps = flatten(Find_All_Components(canvases,DG_name))

def DG_Output_Names(comps,DG_type):
    # Aligns all output names of DG according the bus number and type
    for comp in comps:
        parms = comp.get_parameters()
        name = parms['Name'].split('_')
        suffix = name[1] + '_' + DG_type
        Pfeed = 'Pfeeder_' + suffix
        Qfeed = 'Qfeeder_' + suffix
        Pout = 'Pdg_' + suffix
        Qout = 'Qdg_' + suffix
        voltage = 'Vdg_' + suffix
        current = 'Idg_' + suffix
        rt_flag = 'RTrip_' + suffix
        rocof_flag = 'ROCOFtrip_' + suffix
        comp.set_parameters(current_out=current,voltage_out=voltage,P_out=Pout,Q_out=Qout,P_feeder=Pfeed,Q_feeder=Qfeed,RT_Flag_Out=rt_flag,ROCOF_Flag_Out=rocof_flag)
        if DG_type == 'P3':
            freq = 'FreqMaui_' + suffix
            comp.set_parameters(Freq_Out=freq)

def DG_Feeder_Setup(comps,Active=False):
    status = 1
    if Active:
        status = 0
    for comp in comps:
        comp.set_parameters(DG_Feeder=status)

def RT_ROCOF_Setup(comps,RT_Active=False,ROCOF_Active=False):
    RT_status = 0
    ROCOF_status = 0
    if RT_Active:
        RT_status = 1
    if ROCOF_Active:
        ROCOF_status = 1
    for comp in comps:
        comp.set_parameters(RT_activate=RT_status,ROCOF_activate=ROCOF_status)

def DG_ROCOF_Setup(comps):
    ROCOF_Tlpf = 0.05 # Differentiator filter
    ROCOF_Limit = 3  # Hz/s
    ROCOF_Duration = 0.083 # 5 cycles
    ROCOF_Enable_Signal = 'ROCOF_Enable' # Managed in system
    for comp in comps:
        comp.set_parameters(rocof_relay=ROCOF_Enable_Signal,Trocof_violate=ROCOF_Duration,
            rocof_limit=ROCOF_Limit,Trocof_filter=ROCOF_Tlpf)

def DG_CurLimit_Setup(comps):
    cur_limit_signal = 'DG_CurLimit_Enable'
    cur_limit_val = 1.1
    set_point_limit = 1
    anti_windup = 1
    for comp in comps:
        parms = comp.get_parameters()
        comp.set_parameters(cur_lim_enable=cur_limit_signal,cur_limit=cur_limit_val,anti_windup_method=anti_windup,sp_cur_limit=set_point_limit)
        # Disable cap limit bypass if ideal setup
        if parms['Inner_Loops'] == 0:
            comp.set_parameters(cap_limit_bypass=0)

def DG_General_Setup(comps,P3=False):
    mode = 0 # ideal = 0, loops = 1
    measure_point = 1 # filter inductor = 0, coupling inductor = 1
    Freq_Filter = 0.05 # LPF of PLL output filter
    cap_filter = 0 # engage = 0, disengage = 1
    p_fact = -0.982
    Q_calc = 0 # 0 is Q setpoint, 1 is pf calc
    activate = 0.1 # 'Time_Activate'
    dq_smooth = 0.01 #'Time_DQ_Smooth'
    response = 0.1 #'Time_Response'
    comm = 0.0 #'Time_Comm'
    for comp in comps:
        comp.set_parameters(Inner_Loops=mode, measurement_point=measure_point, Tfreq=Freq_Filter,
            filter_cap_engage=cap_filter, T_Activate = activate, T_Response = response, T_Comm = comm, T_DQ_Smooth = dq_smooth)
        if P3:
            comp.set_parameters(reactive_calc=Q_calc, pf=p_fact)

def DG_Mode_Change(comps,mode):
    # mode; ideal = 0, power = 1, current = 2
    count = 0
    for comp in comps:
        comp.set_parameters(Inner_Loops=mode)
        count += 1
    if mode == 0:
        print('Changed %r models to Ideal Control.' % count)
    if mode == 1:
        print('Changed %r models to Power Loops.' % count)
    if mode == 2:
        print('Changed %r models to Current and Power Loops.' % count)

def DG_Grid_Support(comps):
    # Set up grid support in P3
    layer = 'P3'
    dbd = 0.016 # Droop deadband
    droop = 0.05 # Droop value
    enable_sig = 'DG_Support_Enable' # Enable signal name
    portion = 0.0 # fraction of resource participating in frequency droop
    LPF_time = 0.1 # implementation delay, inline with command signal output

    for comp in comps:
        comp.set_parameters(Fdroop_dbd=dbd, Fdroop=droop, Fdroop_enable=enable_sig, freq_part=portion, T_droop_imp=LPF_time)
        comp.add_to_layer(layer)


##### Generic Unpack for Load and DG

def OpenUnpack(file,load=False,DG=False,P3=False,Tap=False,BusChannel=False,VoltageLevel=False,PSSE_Data=False,Skip=True):
    # Hardcoded to extract all bus load data from file in the format of DayMin_Load
    temp_file = open(file,'r+')
    data = []
    if Skip:
        temp_file.readline()
    if load:
        for line in temp_file:
            line_data = line.split(',')
            #temp_volt = line_data[1].split(' ')
            data.append({'Bus':line_data[0], 'P':line_data[2], 'Q':line_data[3].strip('\n')})
    if DG:
        for line in temp_file:
            line_data = line.split(',')
            if P3:
                data.append({'Bus':line_data[0],'Mbase':line_data[1], 'P':line_data[2], 'PF':line_data[3].strip('\n')})
            else:
                data.append({'Bus':line_data[0],'Mbase':line_data[1], 'P':line_data[2].strip('\n')})
    if Tap:
       for line in temp_file:
            line_data = line.split(',')
            tap = 'Tap_' + str(line_data[0]) + '_' + str(line_data[1])
            data.append({'Name':tap,'Value':line_data[2].strip('\n')})
    if BusChannel:
        for line in temp_file:
            data.append(line.strip('\n'))
    if VoltageLevel:
        for line in temp_file:
            line_data = line.split(',')
            data.append({'Bus':line_data[0],'Vbase':line_data[1].strip('\n'),'V_pscad':0.0,'V_psse':0.0,'V_diff':0.0,'Ph_pscad':0.0,'Ph_psse':0.0,'Ph_diff':0.0})
    if PSSE_Data:
        for line in temp_file:
            line_data = line.split(',')
            data.append({'Bus':line_data[0],'V':line_data[1],'Ph':line_data[2].strip('\n')})

    return data

#### Load Change Code ####

def UpdatePSCADFixed(bus_file_name,canvases):
    # Works with OpenUnpack to update all loads
    bus_data = OpenUnpack(bus_file_name,load=True)
    loads = flatten(Find_All_Components(canvases,'Load_Wrapper'))
    count = 0
    missed = 0
    missed_load = [0,0]
    for load in loads:
        parms = load.get_parameters()
        found = 0
        for bus in bus_data:
            name = 'Wload_' + bus['Bus']
            if parms['Name'] == name:
                found = 1
                P_monitor = 'Pload_' + bus['Bus']
                Q_monitor = 'Qload_' + bus['Bus']
                new_P = str(round(float(bus['P']) / 3,4))
                new_Q = str(round(float(bus['Q']) / 3,4))
                bus_data.remove(bus)
                #LG_volt = str(round(float(bus['Voltage']) / (3**(1/2)),5))
                load.set_parameters(PO=new_P,QO=new_Q,P_out=P_monitor,Q_out=Q_monitor)#,dPdF=2.0,dPdV=1.0)
                #load.set_parameters(T_measure=0.01)
                break
        if found == 1:
            count += 1
        else:
            missed_load[0] += float(parms['PO'])*3
            missed_load[1] += float(parms['QO'])*3
            print('No data, did not change load: %s' % parms['Name'])
            missed += 1
    New_Real = Total(loads,'PO')
    New_Reactive = Total(loads,'QO')
    print('Updated the parameters at %r loads, missed %r' % (count,missed))
    print('New Real is %r MW, new reactive is %r Mvar.' % (round(New_Real[0]*3,3), round(New_Reactive[0]*3,3)))
    print('Not updated real %r MW, not updated reactive %r MVar.' % (round(missed_load[0],3),round(missed_load[1],3)))
    print('Data not applied:')
    for bus in bus_data:
        print('Load at bus %s, P = %r, Q = %r,' % (bus['Bus'],bus['P'],bus['Q']))
#----------------
#### Borrowed Code
#----------------

# Following taken from 
# https://stackoverflow.com/questions/16176742/python-3-replacement-for-deprecated-compiler-ast-flatten-function
def flatten(lst):
    """Flattens a list of lists"""
    return [subelem for elem in lst 
                    for subelem in elem]

def recursive_len(item):
    if type(item) == list:
        return sum(recursive_len(subitem) for subitem in item)
    else:
        return 1



# for elems in scr_meters:
#     for elem in elems:
#         parms = elem.get_parameters()
#         name = parms['Name'].split('_')
#         int(name[2])